<template>
  <div class="docsWrap">
    <div>
      <Icon class="iconCla" size="16" color="#1890FF" type="ios-information-circle" /> 功能使用说明文案</div>
  </div>
</template>

<script>
export default {}
</script>

<style  scoped lang="less">
.docsWrap {
  padding: 20px 0px;
  background: rgba(230, 247, 255, 1);
  border: 1px solid rgba(145, 213, 255, 1);
  border-radius: 4px;
  font-family: 'Microsoft YaHei Regular', 'Microsoft YaHei';
  font-weight: 400;
  font-style: normal;
  font-size: 14px;
  color: rgba(0, 0, 0, 0.647058823529412);
  .iconCla {
    margin-bottom: 3px;
    margin-right: 0px;
    margin-left: 9px;
  }
}
</style>
