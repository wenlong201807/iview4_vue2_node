<template>
  <div>
    <h2>基础数据入口vue</h2>
    <router-view />
  </div>
</template>

<script>
export default {}
</script>

<style>
</style>
