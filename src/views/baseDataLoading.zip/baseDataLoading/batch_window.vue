<template>
  <div>
    <h2>批次管理vue</h2>
  </div>
</template>

<script>
export default {}
</script>

<style>
</style>
