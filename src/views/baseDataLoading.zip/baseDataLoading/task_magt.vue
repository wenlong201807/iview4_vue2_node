<template>
  <div>
    <h2>任务管理vue</h2>
  </div>
</template>

<script>
export default {}
</script>

<style>
</style>
